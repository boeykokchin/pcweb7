<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito"
        rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
        crossorigin="anonymous">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button"
                    data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse"
                    id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link"
                                href="<?php echo e(url('/auth/login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                                href="<?php echo e(url('/auth/register')); ?>">Sign Up</a>
                        </li>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" href="#"
                                class="nav-link dropdown-toggle" role="button"
                                data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false"
                                v-pre><?php echo e(Auth::user()->name); ?>

                            </a>

                            <ul class="dropdown-menu dropdown-menu-right"
                                aria-labelledby="navbarDropdown">
                                <?php if(Auth::user()->can_post()): ?>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(url('/new-post')); ?>">Add new
                                        FoodShare</a>
                                </li>
                                <li class="dropdown-item">
                                    <a
                                        href="<?php echo e(url('/user/'.Auth::id().'/posts')); ?>">My
                                        FoodShares</a>
                                </li>
                                <?php endif; ?>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(url('/user/'.Auth::id())); ?>">My
                                        Profile</a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(url('/logout')); ?>">Logout</a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-info text-center">
                <p class="card-body">
                    <?php echo e(Session::get('message')); ?>

                </p>
            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class='alert alert-danger text-center'>
                <ul class="card-body">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($error); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="card">
                        <div class="card-header">
                            <h2><?php echo $__env->yieldContent('title'); ?></h2>
                            <?php echo $__env->yieldContent('title-meta'); ?>
                        </div>
                        <div class="card-body">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3 text-center">
                <div class="col-md-10 offset-md-1">
                    <p>Copyright © 2020 | <span><a href="#"
                                class="btn btn-outline-success">BOEY</a>
                            HGS
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous">
    </script>
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH /home/boeykokchin/pcweb/7/foodshare/resources/views/layouts/app.blade.php ENDPATH**/ ?>