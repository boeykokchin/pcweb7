<?php $__env->startSection('title', 'Edit FoodShare'); ?>
<?php $__env->startSection('content'); ?>

<form method="post" action='<?php echo e(route('update')); ?>'
    enctype="multipart/form-data">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <input type="hidden" name="post_id"
        value="<?php echo e($post->id); ?><?php echo e(old('post_id')); ?>">
    <div class="form-group">
        <input required="required"
            placeholder="Enter FoodShare title here (max. 50 chars)" type="text"
            maxlength="50" name="title" class="form-control"
            value="<?php if(!old('title')): ?><?php echo e($post->title); ?><?php endif; ?><?php echo e(old('title')); ?>" />
    </div>
    <div class="form-group">
        <textarea name='body' class="form-control" maxlength="500"
            placeholder="Enter FoodShare description here (max. 500 chars)">
            <?php if(!old('body')): ?>
            <?php echo $post->body; ?>

            <?php endif; ?>
            <?php echo old('body'); ?>

        </textarea>
    </div>
    <?php if(!($post->image == "")): ?>
    <div class="form-group">
        <img src="<?php echo e(asset('posts/imgs/'.$post->image)); ?>" alt="image"
            height="150">
    </div>
    <?php endif; ?>
    <div class="form-group">
        <label for="imagefile">FoodShare Picture</label>
        <input name="image" type="file" class="form-control-file" id="imagefile"
            value="<?php echo e($post->image); ?>">
        
    </div>
    <?php if($post->active == '1'): ?>
    <input type="submit" name='publish' class="btn btn-success"
        value="Update" />
    <?php else: ?>
    <input type="submit" name='publish' class="btn btn-success"
        value="Publish" />
    <?php endif; ?>
    <input type="submit" name='save' class="btn btn-secondary"
        value="Save As Draft" />
    <a href="<?php echo e(url('delete/'.$post->id.'?_token='.csrf_token())); ?>"
        class="btn btn-danger">Delete</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/boeykokchin/pcweb/7/foodshare/resources/views/posts/edit.blade.php ENDPATH**/ ?>