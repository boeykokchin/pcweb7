Title: FoodShare Web App
Objective: Provide platform for sharers to share excess food and interested registered users can direct message sharers for details and food collection.
Language: PHP, JS, JQuery, HTML, CSS
Framework: Laravel, Bootstrap
Database: mySQL

CRUD completed for: 'users', 'posts', 'comments'

github code: https://github.com/boeykokchin/foodshare.git

Further works:

1. CRUD for DM chat messages
2. Features - favourites, location, search
3. Reactjs frontend
4. Deployment Heroku
